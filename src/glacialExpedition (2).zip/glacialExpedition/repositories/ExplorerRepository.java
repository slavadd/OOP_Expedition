package glacialExpedition.repositories;

import glacialExpedition.models.explorers.Explorer;

import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class ExplorerRepository implements Repository<Explorer>{
    private List<Explorer> explorers;


    @Override
    public Collection<Explorer> getCollection() {
        return Collections.unmodifiableList(explorers);
    }

    @Override
    public void add(Explorer entity) {
        if (explorers.stream().noneMatch(e -> e.getName().equals(entity.getName()))) {
            explorers.add(entity);
        }

    }

    @Override
    public boolean remove(Explorer entity) {
        return explorers.remove(entity);
    }

    @Override
    public Explorer byName(String name) {
        return explorers.stream().filter(e -> e.getName().equals(name)).findFirst().orElse(null);
    }
}
